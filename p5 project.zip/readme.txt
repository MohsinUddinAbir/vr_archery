1. upload Arduino code inside the Arduino directory (diagram given)
2. open the whole project folder in vs code and install Live server extension. start the liver server. It will open the game in a web browser.
3. for calibration set startShootThreshHold variable inside the sketch.js file to a value (from flex sensor) that you got while pulling the string.